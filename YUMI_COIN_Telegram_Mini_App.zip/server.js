require("dotenv").config();
const express = require("express");
const crypto = require("crypto");
const path = require("path");
const Database = require("better-sqlite3");
const TelegramBot = require("node-telegram-bot-api");

const { BOT_TOKEN, ADMIN_TELEGRAM_ID, WEBAPP_URL } = process.env;
const PORT = Number(process.env.PORT || 3000);
if (!BOT_TOKEN || !ADMIN_TELEGRAM_ID || !WEBAPP_URL ||
    BOT_TOKEN.includes("PASTE_") || ADMIN_TELEGRAM_ID.includes("PASTE_") ||
    WEBAPP_URL.includes("YOUR-HTTPS-DOMAIN")) {
  console.warn("Configure BOT_TOKEN, ADMIN_TELEGRAM_ID, and WEBAPP_URL in .env before using.");
}
const adminId = String(ADMIN_TELEGRAM_ID || "");
const app = express();
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

const db = new Database(path.join(__dirname, "yumi.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS players (
  telegram_id TEXT PRIMARY KEY, username TEXT, first_name TEXT,
  coins INTEGER NOT NULL DEFAULT 0, energy INTEGER NOT NULL DEFAULT 100,
  last_energy_at INTEGER NOT NULL DEFAULT 0, total_taps INTEGER NOT NULL DEFAULT 0,
  daily_claim_at INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
);
`);
const getPlayer = db.prepare("SELECT * FROM players WHERE telegram_id=?");
const upsertPlayer = db.prepare(`
INSERT INTO players(telegram_id,username,first_name,created_at,last_energy_at)
VALUES(@id,@username,@first_name,@now,@now)
ON CONFLICT(telegram_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name
`);
const isAdmin = id => String(id) === adminId && !!adminId && !adminId.includes("PASTE_");

function verifyInitData(initData) {
  if (!BOT_TOKEN || !initData || initData.length > 10000) return null;
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return null;
  params.delete("hash");
  const authDate = Number(params.get("auth_date") || 0);
  if (!authDate || Math.abs(Date.now()/1000 - authDate) > 86400) return null;
  const dataCheckString = [...params.entries()].sort(([a],[b]) => a.localeCompare(b))
    .map(([k,v]) => `${k}=${v}`).join("\n");
  const secretKey = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  const expected = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");
  const a = Buffer.from(hash, "hex"), b = Buffer.from(expected, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) return null;
  try {
    const user = JSON.parse(params.get("user") || "null");
    if (!user || !user.id) return null;
    return user;
  } catch { return null; }
}
function requireUser(req,res,next) {
  const user = verifyInitData(req.get("x-telegram-init-data") || req.body?.initData);
  if (!user) return res.status(401).json({ error: "Telegram ichidan oching: tasdiqlash muvaffaqiyatsiz." });
  req.tgUser = user;
  next();
}
function playerFor(user) {
  const id = String(user.id);
  upsertPlayer.run({ id, username: user.username || "", first_name: user.first_name || "Player", now: Date.now() });
  let p = getPlayer.get(id);
  if (!isAdmin(id)) {
    const now = Date.now();
    const elapsed = Math.floor((now - p.last_energy_at) / 60000);
    if (elapsed > 0 && p.energy < 100) {
      const energy = Math.min(100, p.energy + elapsed);
      db.prepare("UPDATE players SET energy=?,last_energy_at=? WHERE telegram_id=?").run(energy, now, id);
      p = getPlayer.get(id);
    } else if (p.last_energy_at === 0) {
      db.prepare("UPDATE players SET last_energy_at=? WHERE telegram_id=?").run(now,id);
      p = getPlayer.get(id);
    }
  }
  return p;
}
function publicPlayer(p) {
  const admin = isAdmin(p.telegram_id);
  return {
    id: p.telegram_id, username: p.username, firstName: p.first_name,
    coins: admin ? null : p.coins, unlimitedCoins: admin,
    energy: admin ? 100 : p.energy, unlimitedEnergy: admin,
    totalTaps: p.total_taps, isAdmin: admin
  };
}
app.get("/api/me", requireUser, (req,res) => {
  const p = playerFor(req.tgUser);
  res.json({ player: publicPlayer(p), dailyAvailable: isAdmin(p.telegram_id) || Date.now()-p.daily_claim_at >= 86400000 });
});
app.post("/api/tap", requireUser, (req,res) => {
  const p = playerFor(req.tgUser), admin = isAdmin(p.telegram_id);
  if (!admin && p.energy <= 0) return res.status(429).json({ error:"Energiya tugadi. Biroz kuting!", player:publicPlayer(p) });
  const gain = 1;
  if (admin) {
    db.prepare("UPDATE players SET total_taps=total_taps+1 WHERE telegram_id=?").run(p.telegram_id);
  } else {
    db.prepare("UPDATE players SET coins=coins+?, energy=energy-1, total_taps=total_taps+1, last_energy_at=? WHERE telegram_id=?")
      .run(gain, Date.now(), p.telegram_id);
  }
  res.json({ player: publicPlayer(getPlayer.get(p.telegram_id)), gained: gain });
});
app.post("/api/daily", requireUser, (req,res) => {
  const p = playerFor(req.tgUser), admin = isAdmin(p.telegram_id), now = Date.now();
  if (!admin && now-p.daily_claim_at < 86400000) return res.status(429).json({error:"Kunlik mukofot allaqachon olindi."});
  if (!admin) db.prepare("UPDATE players SET coins=coins+500,daily_claim_at=? WHERE telegram_id=?").run(now,p.telegram_id);
  else db.prepare("UPDATE players SET daily_claim_at=? WHERE telegram_id=?").run(now,p.telegram_id);
  res.json({ player:publicPlayer(getPlayer.get(p.telegram_id)), reward:admin ? "∞" : 500 });
});
app.get("/api/leaderboard", requireUser, (req,res) => {
  const rows = db.prepare("SELECT telegram_id,username,first_name,coins,total_taps FROM players ORDER BY coins DESC,total_taps DESC LIMIT 20").all();
  res.json({ leaderboard: rows.map((p,i)=>({rank:i+1,name:p.first_name || p.username || "Player",coins:p.coins,taps:p.total_taps,isYou:p.telegram_id===String(req.tgUser.id)})) });
});
app.get("/api/admin/stats", requireUser, (req,res) => {
  if (!isAdmin(req.tgUser.id)) return res.status(403).json({error:"Faqat admin uchun."});
  const count = db.prepare("SELECT COUNT(*) n FROM players").get().n;
  const taps = db.prepare("SELECT COALESCE(SUM(total_taps),0) n FROM players").get().n;
  res.json({players:count,totalTaps:taps,admin:true});
});

if (BOT_TOKEN && !BOT_TOKEN.includes("PASTE_")) {
  const bot = new TelegramBot(BOT_TOKEN, { polling: true });
  bot.onText(/\/start/, async msg => {
    const keyboard = { inline_keyboard: [[{ text:"🪙 YUMI COIN o‘ynash", web_app:{url:WEBAPP_URL} }]] };
    const hello = `Salom, ${msg.from.first_name || "do‘st"}! 🪙\n\nYUMI COIN — tangalarni yig‘, kunlik mukofotni ol va reytingda ko‘taril!\n\nO‘yinni ochish uchun pastdagi tugmani bos.`;
    bot.sendMessage(msg.chat.id, hello, { reply_markup:keyboard });
  });
  bot.onText(/\/help/, msg => bot.sendMessage(msg.chat.id, "Buyruqlar:\n/start — o‘yinni ochish\n/help — yordam"));
  bot.on("polling_error", err => console.error("Telegram polling error:", err.message));
}
app.get("/health", (_,res)=>res.json({ok:true,app:"YUMI COIN"}));
app.listen(PORT, ()=>console.log(`YUMI COIN server running on port ${PORT}`));
