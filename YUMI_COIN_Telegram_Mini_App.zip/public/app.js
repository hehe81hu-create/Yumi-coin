const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); tg.setHeaderColor("#100c28"); tg.setBackgroundColor("#100c28"); }
const $ = id => document.getElementById(id);
let initData = tg?.initData || "";
let state = {player:null,dailyAvailable:false};
function headers(){return {"Content-Type":"application/json","X-Telegram-Init-Data":initData};}
async function api(url, method="GET"){
  const res = await fetch(url,{method,headers:headers(),body:method==="POST"?"{}":undefined});
  const data = await res.json().catch(()=>({error:"Server javobini o‘qib bo‘lmadi."}));
  if(!res.ok) throw new Error(data.error || "Xatolik yuz berdi.");
  return data;
}
let toastTimer;
function toast(message){$("toast").textContent=message;$("toast").classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>$("toast").classList.remove("show"),2200);}
function render(p){
  state.player=p;
  $("playerName").textContent=p.firstName || "O‘yinchi";
  $("status").textContent=p.isAdmin?"👑 ADMIN — CHEKSIZ REJIM": "YUMI COIN o‘yinchisi";
  $("avatar").textContent=p.isAdmin?"👑":"🌟";
  $("balance").textContent=p.unlimitedCoins?"∞":Number(p.coins||0).toLocaleString("uz-UZ");
  $("tapCount").textContent=Number(p.totalTaps||0).toLocaleString("uz-UZ")+" bosish";
  $("energyText").textContent=p.unlimitedEnergy?"∞ / ∞":`${p.energy} / 100`;
  $("energyBar").style.width=p.unlimitedEnergy?"100%":`${p.energy}%`;
  $("coinButton").style.opacity=(!p.unlimitedEnergy&&p.energy<=0)?.55:1;
}
async function refresh(){
  try{
    if(!initData){$("status").textContent="Telegram ichidan /start orqali oching";$("balance").textContent="—";$("tapMessage").textContent="Mini App tasdiqlangan Telegram sessiyasini talab qiladi.";return;}
    const data=await api("/api/me"); render(data.player); state.dailyAvailable=data.dailyAvailable;
    $("dailyButton").disabled=!data.dailyAvailable;
    $("dailyButton").textContent=data.dailyAvailable?"OLISH":"OLINDI";
    await loadLeaderboard();
  }catch(e){$("status").textContent="Ulanishda xatolik";toast(e.message);}
}
async function loadLeaderboard(){
  try{
    const data=await api("/api/leaderboard");
    $("leaders").innerHTML=data.leaderboard.length?data.leaderboard.map(p=>`<div class="leader"><div class="rank">${p.rank<=3?["🥇","🥈","🥉"][p.rank-1]:p.rank}</div><div class="leader-name">${escapeHtml(p.name)}${p.isYou?'<span class="you">SIZ</span>':''}</div><div class="leader-coins">🪙 ${Number(p.coins).toLocaleString("uz-UZ")}</div></div>`).join(""):'<div class="empty">Hozircha o‘yinchilar yo‘q.</div>';
  }catch(e){$("leaders").innerHTML='<div class="empty">Reytingni ko‘rish uchun Telegram orqali oching.</div>';}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("coinButton").addEventListener("click",async()=>{
  try{
    const data=await api("/api/tap","POST");render(data.player);
    $("tapMessage").textContent=data.player.isAdmin?"👑 Admin uchun cheksiz tangalar!":"+1 YUMI COIN — zo‘r!";
    if(!data.player.isAdmin && data.player.energy%10===0) loadLeaderboard();
  }catch(e){toast(e.message);if(e.message.includes("Energiya"))$("tapMessage").textContent="Energiya tiklanishini kuting.";}
});
$("dailyButton").addEventListener("click",async()=>{
  try{const data=await api("/api/daily","POST");render(data.player);state.dailyAvailable=false;$("dailyButton").disabled=true;$("dailyButton").textContent="OLINDI";toast(data.player.isAdmin?"Admin uchun kunlik bonus cheklanmagan.":"🎉 +500 YUMI COIN olindi!");await loadLeaderboard();}
  catch(e){toast(e.message);}
});
$("refresh").addEventListener("click",refresh);
refresh();
